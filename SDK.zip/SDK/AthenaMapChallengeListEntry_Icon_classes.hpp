#pragma once

// Dumped with Dumper-7!

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x280 - 0x280)
// WidgetBlueprintGeneratedClass AthenaMapChallengeListEntry_Icon.AthenaMapChallengeListEntry_Icon_C
class UAthenaMapChallengeListEntry_Icon_C : public UAthenaMapChallengeListEntry
{
public:

	static class UClass* StaticClass()
	{
		static class UClass* Clss = UObject::FindClassFast("AthenaMapChallengeListEntry_Icon_C");
		return Clss;
	}

};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
