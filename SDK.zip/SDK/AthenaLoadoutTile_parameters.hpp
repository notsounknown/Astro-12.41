#pragma once

// Dumped with Dumper-7!

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x0 - 0x0)
// Function AthenaLoadoutTile.AthenaLoadoutTile_C.BP_OnHovered
struct UAthenaLoadoutTile_C_BP_OnHovered_Params
{
public:
};

// 0x0 (0x0 - 0x0)
// Function AthenaLoadoutTile.AthenaLoadoutTile_C.BP_OnUnhovered
struct UAthenaLoadoutTile_C_BP_OnUnhovered_Params
{
public:
};

// 0x1 (0x1 - 0x0)
// Function AthenaLoadoutTile.AthenaLoadoutTile_C.BP_OnItemSelectionChanged
struct UAthenaLoadoutTile_C_BP_OnItemSelectionChanged_Params
{
public:
	bool                                         bIsSelected;                                       // 0x0(0x1)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
};

// 0x0 (0x0 - 0x0)
// Function AthenaLoadoutTile.AthenaLoadoutTile_C.BP_OnEntryReleased
struct UAthenaLoadoutTile_C_BP_OnEntryReleased_Params
{
public:
};

// 0x51 (0x51 - 0x0)
// Function AthenaLoadoutTile.AthenaLoadoutTile_C.ExecuteUbergraph_AthenaLoadoutTile
struct UAthenaLoadoutTile_C_ExecuteUbergraph_AthenaLoadoutTile_Params
{
public:
	int32                                        EntryPoint;                                        // 0x0(0x4)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_Event_bIsSelected;                          // 0x4(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor)
	uint8                                        Pad_516E[0x3];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	class UCosmeticLoadoutCard_C*                K2Node_DynamicCast_AsCosmetic_Loadout_Card;        // 0x8(0x8)(ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_DynamicCast_bSuccess;                       // 0x10(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor)
	uint8                                        Pad_516F[0x7];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	class UCosmeticLoadoutCard_C*                K2Node_DynamicCast_AsCosmetic_Loadout_Card_1;      // 0x18(0x8)(ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_DynamicCast_bSuccess_1;                     // 0x20(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor)
	uint8                                        Pad_5170[0x7];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	class UCosmeticLoadoutCard_C*                K2Node_DynamicCast_AsCosmetic_Loadout_Card_2;      // 0x28(0x8)(ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_DynamicCast_bSuccess_2;                     // 0x30(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor)
	uint8                                        Pad_5171[0x7];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	class UCosmeticLoadoutCard_C*                K2Node_DynamicCast_AsCosmetic_Loadout_Card_3;      // 0x38(0x8)(ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_DynamicCast_bSuccess_3;                     // 0x40(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor)
	uint8                                        Pad_5172[0x7];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	class UCosmeticLoadoutCard_C*                K2Node_DynamicCast_AsCosmetic_Loadout_Card_4;      // 0x48(0x8)(ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_DynamicCast_bSuccess_4;                     // 0x50(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor)
};

}
}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
